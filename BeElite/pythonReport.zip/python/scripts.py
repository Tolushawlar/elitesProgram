# STRING FORMATING
import math
name = "John"
age = 30
formatted_string = f"My name is {name} and I am {age} years old."
print(formatted_string)


name = "Alice"
age = 25
formatted_string = "My name is {} and I am {} years old.".format(name, age)
print(formatted_string)


name = "Alice"
age = 25
formatted_string = "My name is {} and I am {} years old.".format(name, age)
print(formatted_string)
name = "Alice"
age = 25
formatted_string = "My name is {} and I am {} years old.".format(name, age)
print(formatted_string)


# STRING SLICING
my_string = "Hello, World!"

# Slice from index 0 to index 4 (exclusive)
substring1 = my_string[0:5]
print(substring1)  # Output: "Hello"

# Slice from index 7 to the end of the string
substring2 = my_string[7:]
print(substring2)  # Output: "World!"

# Slice from index 3 to index 9 (exclusive)
substring3 = my_string[3:10]
print(substring3)  # Output: "lo, Wor"

# Slice from index 0 to index 6 (exclusive)
substring4 = my_string[:7]
print(substring4)  # Output: "Hello, "

# Slice the last 6 characters
substring5 = my_string[-6:]
print(substring5)  # Output: "World!"

# Slice every second character from index 0 to the end
substring6 = my_string[::2]
print(substring6)  # Output: "Hlo ol!"

# Reverse the string using slicing
substring7 = my_string[::-1]
print(substring7)  # Output: "!dlroW ,olleH"


# STRING INDEXING
my_string = "Hello, World!"

# Accessing individual characters using indexing
first_character = my_string[0]
second_character = my_string[1]
# Negative indexing starts from the end of the string
last_character = my_string[-1]

print(first_character)    # Output: "H"
print(second_character)   # Output: "e"
print(last_character)     # Output: "!"


# INTEGER AND FLOAT
num_str = "123"
integer_num = int(num_str)
print(integer_num)  # Output: 123

float_num = 3.14
integer_num_from_float = int(float_num)
print(integer_num_from_float)  # Output: 3


num_int = 123
float_num_from_int = float(num_int)
print(float_num_from_int)  # Output: 123.0

num_str = "3.14"
float_num_from_str = float(num_str)
print(float_num_from_str)  # Output: 3.14


# MATH LIBRARY

# Calculate the square root of 25
sqrt_result = math.sqrt(25)
print(sqrt_result)  # Output: 5.0

# Calculate 2 raised to the power of 3
pow_result = math.pow(2, 3)
print(pow_result)  # Output: 8.0

# Calculate the sine of 30 degrees
sin_result = math.sin(math.radians(30))
print(sin_result)  # Output: 0.49999999999999994

# Calculate the factorial of 5
factorial_result = math.factorial(5)
print(factorial_result)  # Output: 120


# LIST
"""
Creating a List:
Lists are created using square brackets [], and elements are separated by commas.
"""
my_list = [1, 2, 3, 4, 5]


""" Accessing Elements:
You can access individual elements of a list using indexing, starting from 0.
"""
first_element = my_list[0]   # Access the first element (1)
third_element = my_list[2]   # Access the third element (3)


"""List Length:
The len() function returns the number of elements in a list.
"""
list_length = len(my_list)   # Returns 5


"""Modifying Elements:
You can modify elements in a list by assigning new values to their respective indices.
"""
my_list[0] = 10   # Change the first element to 10


"""List Slicing:
List slicing allows you to extract a sublist from the original list."""
sliced_list = my_list[1:4]   # Returns [2, 3, 4]


"""Adding Elements:
You can add elements to a list using the append() method or the + operator.
"""
my_list.append(6)   # Add 6 to the end of the list
new_list = my_list + [7, 8, 9]   # Combine two lists


"""Removing Elements:
To remove elements from a list, you can use the remove() method or the del statement."""
my_list.remove(5)   # Remove the element with value 5
del my_list[0]   # Remove the first element from the list


"""List Comprehensions:
List comprehensions provide a concise way to create lists based on existing lists."""
squared_list = [
    x ** 2 for x in my_list]   # Creates a list with squared elements


# list concantination


# Using the + Operator:
list1 = [1, 2, 3]
list2 = [4, 5, 6]

concatenated_list = list1 + list2
print(concatenated_list)  # Output: [1, 2, 3, 4, 5, 6]


# Using the extend() Method:
list1 = [1, 2, 3]
list2 = [4, 5, 6]

list1.extend(list2)
print(list1)  # Output: [1, 2, 3, 4, 5, 6]


# Using List Comprehension:
list1 = [1, 2, 3]
list2 = [4, 5, 6]

concatenated_list = [item for sublist in [list1, list2] for item in sublist]
print(concatenated_list)  # Output: [1, 2, 3, 4, 5, 6]


# Using the * Operator:
list1 = [1, 2, 3]
repeated_list1 = list1 * 2
print(repeated_list1)  # Output: [1, 2, 3, 1, 2, 3]



# LIST COPY METHOD

# Creating a list
original_list = [1, 2, 3, [4, 5]]

# Using copy() to create a shallow copy
shallow_copy_list = original_list.copy()

# Modifying the original_list to demonstrate shallow copy behavior
original_list[0] = 100
original_list[3][0] = 400

# Output the original and copied lists
print("Original List:", original_list)
print("Shallow Copy:", shallow_copy_list)


## OUTPUT
#Original List: [100, 2, 3, [400, 5]]
#Shallow Copy: [1, 2, 3, [400, 5]]


# LIST METHOD

my_list = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3]

print(len(my_list))  # Output: 10
print(sorted(my_list))  # Output: [1, 1, 2, 3, 3, 4, 5, 5, 6, 9]
print(sum(my_list))  # Output: 39
print(min(my_list))  # Output: 1
print(max(my_list))  # Output: 9

my_list.append(7)
print(my_list)  # Output: [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 7]

my_list.extend([8, 9, 10])
print(my_list)  # Output: [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 7, 8, 9, 10]

my_list.sort()
print(my_list)  # Output: [1, 1, 2, 3, 3, 4, 5, 5, 6, 7, 8, 9, 9, 10]

my_list.remove(5)
print(my_list)  # Output: [1, 1, 2, 3, 3, 4, 5, 6, 7, 8, 9, 9, 10]